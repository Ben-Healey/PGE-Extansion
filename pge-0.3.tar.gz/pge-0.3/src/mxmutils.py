#
#  mxmutils
#



#
#  isdigit - returns True if ch is a digit.
#

def isdigit (ch):
    return ch in ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']


#
#
#

def isWhite (ch):
    return ch in [' ', '\t', '\n']


def stop ():
    pass
