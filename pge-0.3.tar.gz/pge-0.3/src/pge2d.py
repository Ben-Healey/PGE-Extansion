#!/usr/bin/env python



#
#
#

def rgb (r, g, b):
    
